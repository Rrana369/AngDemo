import {  Routes } from '@angular/router';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { HomeComponent } from './components/home/home.component';
import { RegistrationFormComponent } from './components/registration-form/registration-form.component';
export const routes: Routes = [
    { path: '', component: HomeComponent },          // default route
    { path: 'about', component: AboutusComponent }, 
    { path: 'registeration', component: RegistrationFormComponent }, 
    //{ path: '**', component: NotFoundComponent }  // wildcard route (optional)
];

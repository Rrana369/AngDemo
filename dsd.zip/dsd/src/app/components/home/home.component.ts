import { Component } from '@angular/core';
import {UserCardComponent} from '../user-card/user-card.component'
import { CommonModule } from '@angular/common';
import { UserService, User } from '../../services/userservice';
@Component({
  selector: 'app-home',
  imports: [UserCardComponent, CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
loading = true;
  users = [
      { id: 1, name: 'Alice', email: 'alice@test.com' },
      { id: 2, name: 'Bob', email: 'bob@test.com' }
    ];
  error = "";
 constructor(private userService: UserService) {}
  ngOnInit() {
   this.userService.getUsers().subscribe({
      next: (data: any) => {
        this.users = data;
        this.loading = false;
      },
      error: (err: any) => {
        this.error = 'Failed to load users';
        this.loading = false;
        console.error(err);
      }
    });
  }
  
  onUserSelected(userId: number) {
    console.log('User selected:', userId);
  }
}

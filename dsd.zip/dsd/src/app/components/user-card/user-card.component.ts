import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-user-card',
  imports: [],
  templateUrl: './user-card.component.html',
  styleUrl: './user-card.component.css'
})
export class UserCardComponent {
  @Input() user!: { id: number; name: string; email: string };
  @Output() selected = new EventEmitter<number>();

   selectUser() {
    this.selected.emit(this.user.id);
  }
}
